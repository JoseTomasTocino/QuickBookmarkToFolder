'use strict';

// import MainManager from './mainManager';

let mainManager = new MainManager();

setTimeout(() =>
{
    mainManager.init();
}, 300);

